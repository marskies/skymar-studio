SKY & MAR BRAND KIT  (v2)

logo/          skymar-lockup-navy.png          S + M lockup, TRANSPARENT, tight crop, 1217x1546
               skymar-lockup-navy-square.png   same, centered on a transparent square
               skymar-lockup-1024/512/256.png  square, sized
               skymar-wordmark-navy.png        "sky & mar studio" wordmark, transparent
               skymar-sunmark-navy.png         sun / S mark alone, transparent
               All navy #122140 on transparency. No background baked in.

link-preview/  og-image-v1.png    1200x630. Upload to the repo root under exactly this name
                                  so the meta tags already written point at it.

favicon/       favicon.ico, favicon-16/32/512.png, apple-touch-icon.png
               Built from the SUN MARK ALONE. The S+M lockup does not survive 16px.
               Use the lockup at 48px and up only.

backgrounds/   dot-grid-*.png        site background, three sizes
               skymar-gradient-bar.png

COLORS
  navy    #122140   logo, headings, body text
  gold    #C4A882   accent only
  sea     #7BA3B3   accent only
  sage    #9BB87A   accent only
  ground  #FFFFFF page   /   #FAFAFA cards
  muted   #666666 secondary text

DOT GRID RECIPE
  white base
  dots: radial-gradient(circle, #bbb 1px, transparent 1px), 24px grid, 35% opacity
  wash 1: ellipse rgba(184,205,214,.2), top 8% right 5%, 45% x 65%
  wash 2: ellipse rgba(232,213,196,.2), bottom 5% left 8%, 40% x 55%
  bottom 40%: linear-gradient(180deg, transparent, #fff)

FONTS  Outfit (headings) - DM Sans (body) - Kalam (handwritten accents)

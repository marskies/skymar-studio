SKY & MAR BRAND KIT

wave-options/   Four M-as-wave marks. Transparent PNG, ~2200px wide, navy #122140.
                a = uniform stroke, clean and most legible as M
                b = calligraphic taper, sharp center vertex  <- recommended
                c = calligraphic, shallower vertex, reads more wave
                d = calligraphic with a sweeping left entry, prettiest, weakest M

brand/          skymar-wordmark-navy.png   wordmark, transparent
                skymar-sunmark-navy.png    the sun/S mark, transparent
                skymar-gradient-bar.png    gold -> sea -> sage accent bar
                dot-grid-*.png             the site background, three sizes
                og-image-dotgrid-v1.png    link preview card on the dot grid

COLORS
  navy    #122140    logo, headings, body text
  gold    #C4A882    accent only
  sea     #7BA3B3    accent only
  sage    #9BB87A    accent only
  ground  #FFFFFF    page   /   #FAFAFA cards
  muted   #666666    secondary text

DOT GRID RECIPE (if rebuilding at another size)
  white base
  dots: radial-gradient(circle, #bbb 1px, transparent 1px), 24px grid, 35% opacity
  wash 1: ellipse rgba(184,205,214,.2), top 8% right 5%, 45% x 65%
  wash 2: ellipse rgba(232,213,196,.2), bottom 5% left 8%, 40% x 55%
  bottom 40%: linear-gradient(180deg, transparent, #fff)

FONTS  Outfit (headings) - DM Sans (body) - Kalam (handwritten accents)
